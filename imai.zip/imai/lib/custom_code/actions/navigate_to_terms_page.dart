// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/terms_and_conditions/terms_and_conditions_page.dart'; // Import the TermsAndConditionsPage widget

Future<void> navigateToTermsPage(BuildContext context) async {
  Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => TermsAndConditionsPage()),
  );
}
