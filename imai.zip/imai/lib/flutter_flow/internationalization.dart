import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'ta', 'ml', 'hi'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? taText = '',
    String? mlText = '',
    String? hiText = '',
  }) =>
      [enText, taText, mlText, hiText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // Authorisation
  {
    '1t9cszqg': {
      'en': 'Create Account',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'c30030q1': {
      'en': 'Welcome!',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'd3184243': {
      'en': 'Fill out the information below in order to create a new  account.',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '9ytlunk7': {
      'en': 'Email',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'p1ojkxbi': {
      'en': 'Password',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'jk3piip8': {
      'en': 'Create Account',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '54yupk9y': {
      'en': 'Or sign in with',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '5veamote': {
      'en': 'Continue with Google',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'gr26ulpa': {
      'en': 'Forgot Password?',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '7vfieems': {
      'en': 'Log In',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '84zujqjp': {
      'en': 'Welcome Back',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'vrk8293s': {
      'en': 'Fill out the information below in order to access your account.',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '7narbohs': {
      'en': 'Email',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '07doi05s': {
      'en': 'Password',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ngbyk2eh': {
      'en': 'Sign In',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'q95q1d6r': {
      'en': 'Or sign in with',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'nzkl4lce': {
      'en': 'Continue with Google',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ylxv8jij': {
      'en': 'Forgot Password?',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'nrpvrtxz': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // HomePagewithadvertisement
  {
    '0dds7bes': {
      'en': 'Hi! Ready to take care of your eye?\n',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ircmbrtj': {
      'en':
          '\n  Your Eye test is FREE...\n                              \n                 - Quickly analyse your eyes sytems.\n                 - Identify if you hava an eye problem.\n                 - Know when to visit your doctor.      \n',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'lkwm4w85': {
      'en': 'Start Free Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '3amhguxz': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // Myprofile
  {
    'rogu0v9i': {
      'en': 'Andrew D.',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'u6vhbur9': {
      'en': 'andrew@domainname.com',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'vxdsltsu': {
      'en': 'Your Account',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'p6icnsue': {
      'en': 'Edit Profile',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'skg0eb2x': {
      'en': 'Notification Settings',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '7qwn9bzx': {
      'en': 'App Settings',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'suvl58m8': {
      'en': 'Terms of Service',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '98ty05gk': {
      'en': 'Log Out',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '75u2tso9': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // editprofile
  {
    '5fx0vf8h': {
      'en': 'Complete Profile',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'h0smrlyt': {
      'en': 'Link your phone number',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'xp8gihlb': {
      'en': 'Enable security by connecting your phone number',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'dh9dko02': {
      'en': 'Your number here...',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'cby7nmod': {
      'en': 'Send OTP',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'zmtd2pup': {
      'en': 'Your information',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'yhq3dmwn': {
      'en': 'First name',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '4pij60wv': {
      'en': 'Last name',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'hcg3vw57': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'x192qf0l': {
      'en': 'Gender\n',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'tbg11058': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'oa7wbnty': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '8d2oami9': {
      'en': 'City',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'g2zbj7ba': {
      'en': 'State',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '0uy46hqf': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'r9qhl0io': {
      'en': 'Save Changes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '18evd0cx': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // Terms_and_conditions
  {
    'yx7mk7ty': {
      'en':
          'Last updated: [Date]\n\nWelcome to IMAI!\n\nThese Terms and Conditions (\"Terms\") govern your use of the IMAI teleophthalmology app (\"IMAI\"), operated by CodeDNA (\"we,\" \"us,\" \"our\"). By using the App, you agree to be bound by these Terms. If you do not agree to these Terms, please do not use the App.\n\n1. Use of the App\nEligibility: You must be at least 18 years old to use the App. If you are under 18, you may use the App only with the consent of a parent or legal guardian.\nAccount: You must create an account to use certain features of the App. You are responsible for maintaining the confidentiality of your account information and for all activities under your account.\n\n\n2. Teleophthalmology Services\nNo Medical Advice: The App provides teleophthalmology services that connect you with licensed healthcare providers. However, the services are not a substitute for in-person consultation with a healthcare provider. Always seek the advice of your physician or other qualified healthcare provider with any questions you may have regarding a medical condition.\nService Limitations: The App may have limitations due to technology, network issues, or other unforeseen circumstances. We do not guarantee that the teleophthalmology services will be uninterrupted or error-free.\n\n3. Privacy\nData Collection: We collect, store, and use your personal data in accordance with our Privacy Policy. By using the App, you agree to the collection and use of your data as described in the Privacy Policy.\nHealth Information: The App may collect health information related to your eye care. We will protect your health information in compliance with applicable laws and regulations, including HIPAA (Health Insurance Portability and Accountability Act) in the United States.\n\n4. User Responsibilities\nAccurate Information: You must provide accurate and complete information when using the App, including health information. Failure to provide accurate information may result in the inability to provide appropriate teleophthalmology services.\nProhibited Activities: You agree not to use the App for any unlawful purpose or in violation of any applicable laws. You also agree not to attempt to gain unauthorized access to the App, disrupt the normal operation of the App, or engage in any activity that interferes with other users\' ability to use the App.\n\n5. Intellectual Property\nOwnership: All content, trademarks, and other intellectual property rights associated with the App are the property of CodeDNA or its licensors. You may not use, reproduce, or distribute any content from the App without our express written consent.\nLicense: We grant you a limited, non-exclusive, non-transferable license to use the App for personal, non-commercial purposes in accordance with these Terms.\n\n6. Fees and Payments\nCharges: Certain features or services offered through the App may be subject to fees. You agree to pay all applicable fees as described in the App.\nPayment Information: You must provide accurate payment information when required. We use third-party payment processors to process payments, and your payment information is subject to their terms and conditions.\n\n7. Disclaimers\nNo Warranty: The App is provided \"as is\" without any warranties of any kind, whether express or implied. We do not warrant that the App will meet your requirements, be available on an uninterrupted basis, or be free of errors or viruses.\nLimitation of Liability: To the fullest extent permitted by law, we disclaim all liability for any direct, indirect, incidental, or consequential damages arising out of or in connection with your use of the App.\n\n8. Indemnification\nYou agree to indemnify, defend, and hold harmless CodeDNA, its affiliates, officers, directors, employees, and agents from and against any claims, liabilities, damages, losses, and expenses arising out of or in any way connected with your use of the App, violation of these Terms, or violation of any rights of another.\n\n9. Termination\nWe reserve the right to suspend or terminate your access to the App at any time, with or without notice, for any reason, including if you breach these Terms.\n\n10. Changes to Terms\nWe may update these Terms from time to time. If we make significant changes, we will notify you by posting the new Terms on the App or by other means. Your continued use of the App after any changes to these Terms constitutes your acceptance of the new Terms.\n\n11. Governing Law\nThese Terms are governed by and construed in accordance with the laws of [Your Jurisdiction], without regard to its conflict of laws principles.\n\n12. Contact Us\nIf you have any questions or concerns about these Terms, please contact us at imai.codedna@gmail.com.\n',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'v0ca7qbe': {
      'en': 'Terms and Conditions',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'dcfszqkz': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // feedpage
  {
    'q2413lm3': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // howdoyouwanttoproceed
  {
    't02xnbt3': {
      'en': 'I Have a problem and want to validate',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'tnk4z0qb': {
      'en': 'Iam not sure If I have a problem',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'v76z79go': {
      'en': 'I have no eye issues - Just want to check',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '7uawaxel': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // one
  {
    'zrjjt8cx': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'nuov31rg': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ul6yr8nd': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '8yoqcjpu': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // two
  {
    'aislk7db': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '8le14m52': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'bjn9ycqr': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'as0sazn3': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // three
  {
    'v2o6d04u': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'e8ugyohp': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'l5tpffam': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'a7cbbqjq': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // four
  {
    'n7rzsbir': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'g2srqo9y': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '92o863ll': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '7vhe7twk': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // five
  {
    'jbea05jn': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'exksggdi': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '1281lg1n': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'd6jcj2n8': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // six
  {
    'za5jclgd': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'lg8ye39s': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'j6x66vb0': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '9pvddthn': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // seven
  {
    'b0zhf6tk': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '25nfe4u1': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ha02kvmq': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'e02gycdy': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // EyeTestProcedure
  {
    't4d0n306': {
      'en': 'Iam Ready',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'jc91qllw': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'fgwhp018': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // CustomerCare
  {
    '77y85zzd': {
      'en': 'AI Chatbot',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'pb7lur4k': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // eyeexcercise
  {
    'urpfr5zh': {
      'en': 'Start workout to begin',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ngyboxid': {
      'en': '1',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'zmodicn2': {
      'en': '1',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '6fturzsa': {
      'en': 'Workout Name',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '6bf15d7g': {
      'en': 'Rep 1',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'orzrbe80': {
      'en': '60 meter strides (slow to medium pace).',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'vp5bfl94': {
      'en': '60 meter strides (slow to medium pace).',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ulagg4a4': {
      'en': 'Start Eye Excercises',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'zocgpfwf': {
      'en': 'Pause Workout',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'w2bftfkv': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // assesement
  {
    'vo75p3o1': {
      'en': 'Eye Assesement Questions',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'acledd1k': {
      'en': 'Assessement',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '3xzwvgti': {
      'en': 'Do you have any other symptomps ?',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '2bg8b96i': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'im3icyjy': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'c9oelcpf': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // eight
  {
    'vv3vt4qj': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ju8mq1q6': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '2r7clab4': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    't5anrjo8': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // nine
  {
    'o2imrd9l': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'j4la5xpu': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'nekbzn2r': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'xgio7hr3': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // ten
  {
    '5r83s955': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'eovvq7vz': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'jneihevv': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'fdwcgoev': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // eleven
  {
    'tm8ulqkp': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'tm5nhqum': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '4n3kbijd': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'rnl2551c': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // thieteen
  {
    'z4d0dxma': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'tdr4nlk8': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ql0fsfni': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'gis1tx7k': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // sixteen
  {
    'c0v7se2u': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '709xpneq': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'fcu60dc0': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '1eas1ivm': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // fourteen
  {
    '1oownoya': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'lvnqdom4': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'w0dkp9mr': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'sodtharg': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // seventeen
  {
    '8b8mhgwx': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'dyuakrbm': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'umn7g5ed': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'w4wx3k05': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // twelve
  {
    '6m4yi307': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '419986y1': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'adz8bvba': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'lka5lmir': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // eighteen
  {
    'n7djvx9n': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'jqz3srho': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'do5owlyk': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'lql9l0jk': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // nineteen
  {
    'kqdho4b6': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'd1wfdt3e': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'xs3ckik3': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'uhfz5rsb': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // twenty
  {
    'o8fzx9hy': {
      'en': 'Eye Test',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'prvcz98o': {
      'en': 'No',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '6xsv9vh0': {
      'en': 'Yes',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'm0snwzls': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // score
  {
    'q3oysd6m': {
      'en': 'Your RESULT',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'osmlohi5': {
      'en': 'Home',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
  // Miscellaneous
  {
    'quslcnbm': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ftrfm3iq': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'z4wm3lsp': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'p7y97oru': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '54z99mnx': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'fxwhrxhh': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'wyefkfrt': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'h61495q1': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'g2lfu9af': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'nwl7n3kl': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '7b6024dw': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '91i1mo8s': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    't1r4a66o': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'leuxbqcy': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'p91pgbju': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'ftn4poko': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '7kk2c4lk': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'utn2uq0n': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '7a1uv3xs': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'smazz1bw': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '53yvgga8': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'dntgh570': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    '3qks7ldu': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'shee0fxe': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
    'vgms2kcn': {
      'en': '',
      'hi': '',
      'ml': '',
      'ta': '',
    },
  },
].reduce((a, b) => a..addAll(b));
