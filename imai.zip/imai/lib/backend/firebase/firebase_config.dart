import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAi-htz3bXRDdszDYofZoWn1CclvQavkz4",
            authDomain: "imai-2mrygo.firebaseapp.com",
            projectId: "imai-2mrygo",
            storageBucket: "imai-2mrygo.appspot.com",
            messagingSenderId: "953510792369",
            appId: "1:953510792369:web:35d929661b3d96ea2c2690"));
  } else {
    await Firebase.initializeApp();
  }
}
