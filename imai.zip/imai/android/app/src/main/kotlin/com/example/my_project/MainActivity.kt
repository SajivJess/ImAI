package com.mycompany.imai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
